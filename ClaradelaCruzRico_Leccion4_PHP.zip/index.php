<?php

    //EJERCICIO 1
    echo "--------------EJERCICIO 1-----------------<br>";
    function menorOMayorEdad (string $nombre, int $edad){
        if($edad >= 18){
            echo $nombre . " tiene ". $edad." años y es mayor de edad<br>";
        }else{
            echo $nombre . " tiene ". $edad." años y es menor de edad<br>";
        }
    }

    menorOMayorEdad("Pepe", 43);
    menorOMayorEdad("Lucia", 5);

    //EJERCICIO 2
    echo "--------------EJERCICIO 2-----------------<br>";
    function parOImpar (int $numero){
        if($numero%2 == 0){
            echo "PAR";
        }else{
            echo "IMPAR";
        }
        echo "<br>";
    }

    parOImpar(3);
    parOImpar(8);

    //EJERCICIO 3
    echo "--------------EJERCICIO 3-----------------<br>";
    function mayorDeTres(int $num1, int $num2, int $num3 ){
        $numeros = [$num1, $num2, $num3];
        echo max($numeros)."<br>";
    }

    mayorDeTres(12,8,65);

    //EJERCICIO 4
    echo "--------------EJERCICIO 4-----------------<br>";
    function factorial(int $num){
        if($num >= 0){
            $resultado =1;
            for($i=1;$i<$num + 1;$i++){
                $resultado*=$i;
            }
            echo "Su factorial es ". $resultado."<br>";
        }else{
            echo "Su factorial no existe <br>";
        }
    }

    factorial(3);
    factorial(5);
    factorial(10);

    //excepciones
    factorial(0);
    factorial(-10);

    //EJERCICIO 5
    echo "--------------EJERCICIO 5-----------------<br>";
    $numeros=[1,3,4,12,7,34,22,45,2,4,99,35, 21,55,76,29,83,22, 33];

    function maximoEnArray(array $numeros){
        $maximo=0;
        for($i=0;$i<count($numeros);$i++){
            if($maximo<$numeros[$i]){
                $maximo=$numeros[$i];
            }
        }
        echo "El máximo es : ".$maximo;
    }

    maximoEnArray($numeros);
?>
