<?php

//ini_set('display_errors', '1');
//error_reporting(E_ALL);
echo "<pre>";
print_r($GLOBALS); //va a recoger las variables globales que declaremos
echo "</pre>";

echo "<pre>";
    print_r( $_FILES ); 
    echo "</pre>";


//INICIO SESION
if (isset($_POST['login'])) {
    $envioOk = validar();

    if($envioOk){
        if(!file_exists("uploads")){
            mkdir("uploads");
        }

        $origen = $_FILES['foto']['tmp_name'];
        $destino = "uploads/".$_FILES['foto']['name'];

        if( move_uploaded_file( $origen, $destino ) ){
            echo "Archivo guardado con éxito";
        }
    }
}

//BUSQUEDA
if (isset($_GET['busqueda'])) {
    global $productos;
    $productos = buscarProducto();
}

//LOGOUT
if (isset($_POST['salir'])) {
    borrarImagen();
}

function setError(string $errorMensaje)
{
    global $error;
    $error = $errorMensaje;
}

//-----------

function borrarImagen(){
    unlink( "uploads/".$_FILES['foto']['name']); 
    
}


function rellenarListaProductos()
{
    return  [
        [
            "id" => 1,
            "title" => "Lenovo IdeaPad 3",
            "description" => "Lenovo IdeaPad 3 15IAU7 Intel Core i5-1235U/16GB/512GB SSD/15.6''",
            "img" => "https://thumb.pccomponentes.com/w-300-300/articles/1063/10639213/1359-lenovo-ideapad-3-15iau7-intel-core-i5-1235u-16gb-512gb-ssd-156.jpg",
            "price" => 357
        ],
        [
            "id" => 2,
            "title" => "Logitech G502",
            "description" => "Logitech G502 Hero Ratón Gaming 25600DPI",
            "img" => "https://thumb.pccomponentes.com/w-300-300/articles/17/179806/244-logitech-g502-hero-raton-gaming-16000dpi-caracteristicas.jpg",
            "price" => 38.68
        ],
        [
            "id" => 3,
            "title" => "Google Nest Mini",
            "description" => "Google Nest Mini Altavoz Inteligente con Asistente Tiza",
            "img" => "https://thumb.pccomponentes.com/w-300-300/articles/24/243521/image-mini2-19-0403-0294-10-white-ttq-r04-simp.jpg",
            "price" => 22.89
        ],
        [
            "id" => 4,
            "title" => "HyperX Cloud Flight",
            "description" => "HyperX Cloud Flight Auriculares Gaming Inalámbricos",
            "img" => "https://thumb.pccomponentes.com/w-300-300/articles/1004/10042294/1601-hyperx-cloud-flight-auriculares-gaming-inalambricos.jpg",
            "price" => 69.99
        ],
        [
            "id" => 5,
            "title" => "AOC 24G2SAE",
            "description" => "AOC 24G2SAE/BK 23.8'' LED FullHD 165Hz FreeSync Premium",
            "img" => "https://thumb.pccomponentes.com/w-300-300/articles/1002/10026204/1597-aoc-27g2sae-bk-27-wled-fullhd-165hz-freesync-premium.jpg",
            "price" => 149.52
        ],
        [
            "id" => 6,
            "title" => "Silla Gaming",
            "description" => "Nacon CH-550 Silla Gaming 118.99€",
            "img" => "https://thumb.pccomponentes.com/w-530-530/articles/28/289561/nacon-ch-550-silla-gaming.jpg",
            "price" => 118.99
        ]

    ];
}

function buscarProducto()
{
    $productos = rellenarListaProductos();
    $productosEncontrados = [];
    if (isset($productos)) {
        foreach ($productos as $prod) {

            if (str_contains(strtolower( $prod["title"] ) , strtolower($_GET['busqueda'] ))) {
               // $productosEncontrados = [$productosEncontrados, $prod];
                array_push( $productosEncontrados, $prod);
                //echo 'introducido';
            }
        }
    }
   
    return $productosEncontrados;
}

function validar()
{

    if (!obligatoriosRellenos()) {
        //echo "Faltan datos obligatorios";
        setError("Faltan datos obligatorios");
        //echo "false obligatoriosRellenos";
        return false;
    }

    if (!formatoCorreo()) {
        //echo "false formatocorreo";
        return false;
    }

    if (!formatoConstrasena()) {
        // echo "false formatoConstrasena";
        return false;
    }

    if(!formatoImagen()){
         echo "false formatoImagen";
        return false;
    }
    //echo "true";
    return true;
};

function obligatoriosRellenos()
{

    if (
        !isset($_POST['email']) || empty($_POST['email']) ||
        !isset($_POST['password']) || empty($_POST['password'])
    ) {
        return false;
    }
    return true;
};

function formatoImagen(){
    if($_FILES['foto']['type'] == "image/jpg" ||
    $_FILES['foto']['type'] == "image/png" ||
    $_FILES['foto']['type'] == "image/jpeg"){
        return true; 
    }
    setError("Extension de imagen incorrecta");
    return false;
}

function formatoCorreo()
{
    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    return true;
};

function formatoConstrasena()
{
    $constrasena = $_POST['password'];
    //La contraseña tiene que tener al menos 6 caracteres, y no puede contener las palabras "password" ni "123456"
    if (strlen($constrasena) < 6) {
        //echo "La contraseña tiene que tener al menos 6 caracteres";
        setError("La contraseña tiene que tener al menos 6 caracteres");
        return false;
    } else if (preg_match('/password/', $constrasena)) {
        //echo "La contraseña no puede contener las palabras 'password'";
        setError("La contraseña no puede contener las palabras 'password'");

        return false;
    } else if (preg_match('/123456/', $constrasena)) {
        //echo "La contraseña no puede contener las palabras '123456'";
        setError("La contraseña no puede contener las palabras '123456'");

        return false;
    }

    return true;
}




?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tienda online PHP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>
    <nav class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="index.html">LOGO</a>
        <ul class="nav justify-content-end">
            <a class="link" href="#">Servicios</a>
            <a class="link" href="#">Sobre nosotros</a>
            <a class="link" href="#">Contacto</a>
            <?php
                if (isset($envioOk) &&  $envioOk) { ?>
                    <img src=<?= "uploads/".$_FILES['foto']['name'] ?> id="imagenPerfil" alt="">

            <?php } ?>
            <li class="nav-item">
            <?php
                if (isset($envioOk) &&  $envioOk) { ?>
                
                    <a class="btn btn-outline-danger" href="index.php" name="salir">Logout</a>
                <?php } else { ?>
                    <a class="btn btn-outline-light" href="index.php" >Login</a> 
                <?php } ?>
            </li>
        </ul>
    </nav>
    <main>
        <div class="container">
        <?php
            if (isset($envioOk) &&  $envioOk) { ?>

            <div class="row justify-content-center">
                <form action="" method="get">
                    <div class="mb-3">
                        <input type="text" class="form-control" name="busqueda">
                    </div>
                    <button type="search" class="btn btn-primary" name="search">Enviar</button>
                </form>
            </div>

            <div class="row">
                <?php
                if (isset($productos)) {
                    foreach ($productos as $prod) { ?>
                        <div class="card" style="width: 18rem;">
                            <img src=<?= $prod["img"] ?> alt="">
                            <div class="card-body">
                                <h5 class="card-title"><?= $prod["title"] ?></h5>
                                <p class="card-text"> <?= $prod["description"] ?><br>
                                    <b> <?= $prod["price"] ?> </b>
                                </p>
                                <a href="#" class="btn btn-primary"> Ver </a>
                                <a href="#" class="btn btn-primary"> Añadir </a>
                            </div>
                        </div>
                <?php ;
                    }
                }; ?>
            </div>

            <?php } ?>




            <div class="row justify-content-center">
                <div class="col-6">
                    <?php
                    if (isset($envioOk) &&  $envioOk) { ?>

                        <div class="col-sm-10">
                            <p> Bienvenido : <?php echo $_POST['email'] ?></p>
                        </div>

                    <?php } else {

                    ?>
                        <form action="index.php" method="POST" enctype="multipart/form-data">
                            <div class="row mb-3">
                                <label for="email" class="col-sm-2 col-form-label">Email</label>
                                <div class="col-sm-10">
                                    <input type="email" class="form-control" id="email" name="email">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="password" class="col-sm-2 col-form-label">Password</label>
                                <div class="col-sm-10">
                                    <input type="password" class="form-control" id="password" name="password">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="foto" class="col-sm-2 col-form-label">Foto</label>
                                <div class="col-sm-10">
                                    <input type="file" class="form-control"  id="foto" name="foto">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary" name="login">Login</button>
                        </form>
                        <?php if(isset($error)){ ?>
                        <div class="alert alert-danger ">
                        <?=  $error  ?> 
                        </div>
                        <?php } ?>
                    <?php

                    }
                    ?>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-4"></div>
                <div class="col-4"></div>
                <div class="col-4">Autor: Tú </div>
            </div>
        </div>


    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>



</body>

</html>